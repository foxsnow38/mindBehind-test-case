## Users   

nickname: admin
password: 12345678

nickname: user
password 12345678

